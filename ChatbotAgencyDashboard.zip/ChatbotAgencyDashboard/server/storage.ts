import { type User, type InsertUser, type Bot, type InsertBot } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // User methods
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Bot methods
  getAllBots(): Promise<Bot[]>;
  getBot(id: string): Promise<Bot | undefined>;
  createBot(bot: InsertBot): Promise<Bot>;
  updateBot(id: string, bot: Partial<InsertBot>): Promise<Bot | undefined>;
  deleteBot(id: string): Promise<boolean>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private bots: Map<string, Bot>;

  constructor() {
    this.users = new Map();
    this.bots = new Map();
    
    // Create default admin user
    const adminId = randomUUID();
    this.users.set(adminId, {
      id: adminId,
      username: "admin@chatbotagency.com",
      password: "admin123",
    });
    
    // Create some initial bots for demo
    this.seedBots();
  }

  private seedBots() {
    const bot1: Bot = {
      id: randomUUID(),
      name: "Customer Support Bot",
      client: "TechCorp Inc.",
      welcomeMessage: "Hi! How can I help you today?",
      suggestedMessages: ["Pricing", "Support", "Contact Sales"],
      webhookUrl: "https://api.techcorp.com/webhook",
      formWebhookUrl: "https://api.techcorp.com/form",
      theme: "#4f46e5",
      headerText: "TechCorp Support",
      footerText: "Powered by AI",
      footerLink: "https://techcorp.com",
      watermark: "TechCorp AI",
      chatBubbleShape: "rounded",
      width: 400,
      height: 500,
      status: "active",
      createdAt: new Date("2024-01-15"),
    };

    const bot2: Bot = {
      id: randomUUID(),
      name: "Sales Assistant",
      client: "RetailHub",
      welcomeMessage: "Welcome! Looking for something specific?",
      suggestedMessages: ["Product Info", "Pricing", "Schedule Demo"],
      webhookUrl: "https://api.retailhub.com/webhook",
      formWebhookUrl: null,
      theme: "#7c3aed",
      headerText: "RetailHub Sales",
      footerText: "Shop with confidence",
      footerLink: "https://retailhub.com",
      watermark: "RetailHub",
      chatBubbleShape: "box",
      width: 380,
      height: 550,
      status: "active",
      createdAt: new Date("2024-02-20"),
    };

    const bot3: Bot = {
      id: randomUUID(),
      name: "FAQ Bot",
      client: "StartupXYZ",
      welcomeMessage: "Have questions? I'm here to help!",
      suggestedMessages: ["Getting Started", "Billing", "Technical Support"],
      webhookUrl: "https://api.startupxyz.com/webhook",
      formWebhookUrl: "https://api.startupxyz.com/form",
      theme: "#06b6d4",
      headerText: "StartupXYZ Help",
      footerText: "Need more help?",
      footerLink: "https://startupxyz.com/help",
      watermark: "StartupXYZ",
      chatBubbleShape: "minimal",
      width: 420,
      height: 480,
      status: "inactive",
      createdAt: new Date("2024-03-10"),
    };

    this.bots.set(bot1.id, bot1);
    this.bots.set(bot2.id, bot2);
    this.bots.set(bot3.id, bot3);
  }

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async getAllBots(): Promise<Bot[]> {
    return Array.from(this.bots.values()).sort(
      (a, b) => b.createdAt.getTime() - a.createdAt.getTime()
    );
  }

  async getBot(id: string): Promise<Bot | undefined> {
    return this.bots.get(id);
  }

  async createBot(insertBot: InsertBot): Promise<Bot> {
    const id = randomUUID();
    const bot: Bot = {
      id,
      name: insertBot.name,
      client: insertBot.client,
      welcomeMessage: insertBot.welcomeMessage,
      suggestedMessages: insertBot.suggestedMessages,
      webhookUrl: insertBot.webhookUrl,
      formWebhookUrl: insertBot.formWebhookUrl ?? null,
      theme: insertBot.theme ?? "#4f46e5",
      headerText: insertBot.headerText ?? null,
      footerText: insertBot.footerText ?? null,
      footerLink: insertBot.footerLink ?? null,
      watermark: insertBot.watermark ?? null,
      chatBubbleShape: insertBot.chatBubbleShape ?? "rounded",
      width: insertBot.width ?? 400,
      height: insertBot.height ?? 500,
      status: insertBot.status ?? "active",
      createdAt: new Date(),
    };
    this.bots.set(id, bot);
    return bot;
  }

  async updateBot(id: string, updates: Partial<InsertBot>): Promise<Bot | undefined> {
    const bot = this.bots.get(id);
    if (!bot) return undefined;

    const updatedBot: Bot = { ...bot, ...updates };
    this.bots.set(id, updatedBot);
    return updatedBot;
  }

  async deleteBot(id: string): Promise<boolean> {
    return this.bots.delete(id);
  }
}

export const storage = new MemStorage();

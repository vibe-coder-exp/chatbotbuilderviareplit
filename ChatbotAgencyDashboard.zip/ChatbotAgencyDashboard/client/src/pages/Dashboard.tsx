import { useApp } from "@/contexts/AppContext";
import StatCard from "@/components/StatCard";
import RecentActivity from "@/components/RecentActivity";
import { Button } from "@/components/ui/button";
import { Bot, Activity, MessageSquare, Plus } from "lucide-react";
import { useLocation } from "wouter";

export default function Dashboard() {
  const { bots } = useApp();
  const [, setLocation] = useLocation();

  const activeBots = bots.filter((bot) => bot.status === "active").length;
  const totalMessages = Math.floor(Math.random() * 2000) + 500;

  const recentActivities = bots.slice(0, 5).map((bot, index) => ({
    id: bot.id,
    type: index % 3 === 0 ? ("created" as const) : index % 3 === 1 ? ("updated" as const) : ("error" as const),
    botName: bot.name,
    message:
      index % 3 === 0
        ? `New bot created for ${bot.client}`
        : index % 3 === 1
        ? "Bot configuration updated"
        : "Webhook connection issue",
    timestamp: new Date(bot.createdAt),
  }));

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Dashboard</h1>
          <p className="text-muted-foreground mt-1">
            Overview of your AI chatbots
          </p>
        </div>
        <Button
          onClick={() => setLocation("/bots")}
          data-testid="button-create-bot"
          className="gap-2"
        >
          <Plus className="w-4 h-4" />
          Create New Bot
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <StatCard
          title="Total Bots"
          value={bots.length}
          icon={Bot}
          iconColor="text-primary"
          iconBgColor="bg-primary/10"
        />
        <StatCard
          title="Active Bots"
          value={activeBots}
          icon={Activity}
          iconColor="text-green-600"
          iconBgColor="bg-green-100"
        />
        <StatCard
          title="Total Messages"
          value={totalMessages.toLocaleString()}
          icon={MessageSquare}
          iconColor="text-purple-600"
          iconBgColor="bg-purple-100"
        />
      </div>

      <RecentActivity activities={recentActivities} />
    </div>
  );
}

import { useRoute } from "wouter";
import { useApp } from "@/contexts/AppContext";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Copy, Check } from "lucide-react";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";

export default function EmbedPreview() {
  const [, params] = useRoute("/embed/:id");
  const { bots } = useApp();
  const { toast } = useToast();
  const [copied, setCopied] = useState(false);

  const bot = bots.find((b) => b.id === params?.id);

  if (!bot) {
    return (
      <div className="p-6">
        <Card className="p-12 text-center">
          <p className="text-muted-foreground">Bot not found</p>
        </Card>
      </div>
    );
  }

  const embedCode = `<iframe src="${window.location.origin}/chatbot/${bot.id}" width="${bot.width}" height="${bot.height}" frameborder="0"></iframe>`;

  const scriptCode = `<script src="${window.location.origin}/embed.js" data-bot-id="${bot.id}" data-width="${bot.width}" data-height="${bot.height}"></script>`;

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    toast({
      title: "Copied to clipboard",
      description: "Embed code has been copied to your clipboard.",
    });
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="p-6 space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-foreground">Embed Code</h1>
        <p className="text-muted-foreground mt-1">
          Copy the code below to embed {bot.name} on your website
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="space-y-6">
          <Card className="p-6">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-semibold text-foreground">
                iFrame Code
              </h2>
              <Button
                size="sm"
                variant="outline"
                onClick={() => copyToClipboard(embedCode)}
                data-testid="button-copy-iframe"
                className="gap-2"
              >
                {copied ? (
                  <Check className="w-4 h-4" />
                ) : (
                  <Copy className="w-4 h-4" />
                )}
                {copied ? "Copied" : "Copy"}
              </Button>
            </div>
            <div className="bg-muted rounded-lg p-4 font-mono text-sm overflow-x-auto">
              <code className="text-foreground">{embedCode}</code>
            </div>
          </Card>

          <Card className="p-6">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-semibold text-foreground">
                Script Tag
              </h2>
              <Button
                size="sm"
                variant="outline"
                onClick={() => copyToClipboard(scriptCode)}
                data-testid="button-copy-script"
                className="gap-2"
              >
                {copied ? (
                  <Check className="w-4 h-4" />
                ) : (
                  <Copy className="w-4 h-4" />
                )}
                {copied ? "Copied" : "Copy"}
              </Button>
            </div>
            <div className="bg-muted rounded-lg p-4 font-mono text-sm overflow-x-auto">
              <code className="text-foreground">{scriptCode}</code>
            </div>
          </Card>

          <Card className="p-6">
            <h2 className="text-lg font-semibold text-foreground mb-4">
              Bot Configuration
            </h2>
            <dl className="space-y-2 text-sm">
              <div className="flex justify-between">
                <dt className="text-muted-foreground">Client:</dt>
                <dd className="font-medium text-foreground">{bot.client}</dd>
              </div>
              <div className="flex justify-between">
                <dt className="text-muted-foreground">Style:</dt>
                <dd className="font-medium text-foreground capitalize">
                  {bot.chatBubbleShape}
                </dd>
              </div>
              <div className="flex justify-between">
                <dt className="text-muted-foreground">Dimensions:</dt>
                <dd className="font-medium text-foreground">
                  {bot.width}×{bot.height}px
                </dd>
              </div>
              <div className="flex justify-between">
                <dt className="text-muted-foreground">Theme:</dt>
                <dd className="flex items-center gap-2">
                  <div
                    className="w-4 h-4 rounded border border-border"
                    style={{ backgroundColor: bot.theme }}
                  />
                  <span className="font-medium text-foreground">{bot.theme}</span>
                </dd>
              </div>
            </dl>
          </Card>
        </div>

        <div>
          <Card className="p-6 sticky top-6">
            <h2 className="text-lg font-semibold text-foreground mb-4">
              Live Preview
            </h2>
            <div
              className="border-2 border-border mx-auto"
              style={{
                width: Math.min(bot.width, 400),
                height: Math.min(bot.height, 500),
              }}
            >
              <div
                className="p-4 text-white font-semibold flex items-center justify-between"
                style={{ backgroundColor: bot.theme }}
              >
                <span>{bot.headerText || "Chat"}</span>
                {bot.watermark && (
                  <span className="text-xs opacity-75">{bot.watermark}</span>
                )}
              </div>
              <div className="p-4 bg-background h-[calc(100%-8rem)] overflow-y-auto space-y-3">
                <div className="bg-muted rounded-lg p-3 max-w-[80%]">
                  <p className="text-sm text-foreground">{bot.welcomeMessage}</p>
                </div>
                {bot.suggestedMessages.length > 0 && (
                  <div className="flex flex-wrap gap-2">
                    {bot.suggestedMessages.slice(0, 3).map((msg, idx) => (
                      <Button
                        key={idx}
                        variant="outline"
                        size="sm"
                        className="text-xs"
                      >
                        {msg}
                      </Button>
                    ))}
                  </div>
                )}
              </div>
              <div className="p-3 bg-muted border-t border-border">
                <p className="text-xs text-center text-muted-foreground">
                  {bot.footerText}
                </p>
              </div>
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}

import { useState } from "react";
import { useApp } from "@/contexts/AppContext";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import BotTable from "@/components/BotTable";
import BotFormModal from "@/components/BotFormModal";
import { Plus } from "lucide-react";
import { type Bot } from "@shared/schema";
import { useLocation } from "wouter";
import { useToast } from "@/hooks/use-toast";

export default function Bots() {
  const { bots, addBot, updateBot, deleteBot } = useApp();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingBot, setEditingBot] = useState<Bot | null>(null);
  const [, setLocation] = useLocation();
  const { toast } = useToast();

  const handleEdit = (bot: Bot) => {
    setEditingBot(bot);
    setIsModalOpen(true);
  };

  const handleDelete = async (id: string) => {
    if (confirm("Are you sure you want to delete this bot?")) {
      try {
        await deleteBot(id);
        toast({
          title: "Bot deleted",
          description: "The bot has been successfully deleted.",
        });
      } catch (error) {
        toast({
          title: "Error",
          description: "Failed to delete bot. Please try again.",
          variant: "destructive",
        });
      }
    }
  };

  const handleSave = async (botData: Omit<Bot, "id" | "createdAt">) => {
    try {
      if (editingBot) {
        await updateBot(editingBot.id, botData);
        toast({
          title: "Bot updated",
          description: "The bot has been successfully updated.",
        });
      } else {
        await addBot(botData);
        toast({
          title: "Bot created",
          description: "The bot has been successfully created.",
        });
      }
      setIsModalOpen(false);
      setEditingBot(null);
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to save bot. Please try again.",
        variant: "destructive",
      });
    }
  };

  const handleViewEmbed = (bot: Bot) => {
    setLocation(`/embed/${bot.id}`);
  };

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Bots</h1>
          <p className="text-muted-foreground mt-1">
            Manage your AI chatbots
          </p>
        </div>
        <Button
          onClick={() => {
            setEditingBot(null);
            setIsModalOpen(true);
          }}
          data-testid="button-create-new-bot"
          className="gap-2"
        >
          <Plus className="w-4 h-4" />
          Create New Bot
        </Button>
      </div>

      <Card className="overflow-hidden">
        {bots.length === 0 ? (
          <div className="p-12 text-center">
            <p className="text-muted-foreground mb-4">
              No bots created yet. Create your first bot to get started.
            </p>
            <Button
              onClick={() => setIsModalOpen(true)}
              data-testid="button-create-first-bot"
            >
              <Plus className="w-4 h-4 mr-2" />
              Create Your First Bot
            </Button>
          </div>
        ) : (
          <BotTable bots={bots} onEdit={handleEdit} onDelete={handleDelete} />
        )}
      </Card>

      <BotFormModal
        isOpen={isModalOpen}
        onClose={() => {
          setIsModalOpen(false);
          setEditingBot(null);
        }}
        onSave={handleSave}
        bot={editingBot}
      />
    </div>
  );
}

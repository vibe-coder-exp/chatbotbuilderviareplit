import { useState } from "react";
import { useApp } from "@/contexts/AppContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";

export default function Settings() {
  const { adminSettings, updateAdminSettings } = useApp();
  const { toast } = useToast();
  const [formData, setFormData] = useState(adminSettings);

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    updateAdminSettings(formData);
    toast({
      title: "Settings saved",
      description: "Your settings have been successfully updated.",
    });
  };

  const handleTestWebhook = () => {
    console.log("Testing webhook...");
    toast({
      title: "Webhook test",
      description: "Webhook test initiated. Check console for details.",
    });
  };

  return (
    <div className="p-6 space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-foreground">Settings</h1>
        <p className="text-muted-foreground mt-1">
          Manage your admin profile and default configurations
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="space-y-6">
          <Card className="p-6">
            <h2 className="text-lg font-semibold text-foreground mb-4">
              Admin Information
            </h2>
            <form onSubmit={handleSave} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="name">Name</Label>
                <Input
                  id="name"
                  value={formData.name}
                  onChange={(e) =>
                    setFormData({ ...formData, name: e.target.value })
                  }
                  placeholder="Your Name"
                  data-testid="input-admin-name"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="email">Email</Label>
                <Input
                  id="email"
                  type="email"
                  value={formData.email}
                  onChange={(e) =>
                    setFormData({ ...formData, email: e.target.value })
                  }
                  placeholder="admin@example.com"
                  data-testid="input-admin-email"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="password">New Password</Label>
                <Input
                  id="password"
                  type="password"
                  placeholder="Leave blank to keep current"
                  data-testid="input-new-password"
                />
              </div>

              <Button type="submit" className="w-full" data-testid="button-save-admin">
                Save Admin Info
              </Button>
            </form>
          </Card>

          <Card className="p-6">
            <h2 className="text-lg font-semibold text-foreground mb-4">
              Default Theme Settings
            </h2>
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="defaultTheme">Default Color Theme</Label>
                <div className="flex gap-2">
                  <Input
                    id="defaultTheme"
                    type="color"
                    value={formData.defaultTheme}
                    onChange={(e) =>
                      setFormData({ ...formData, defaultTheme: e.target.value })
                    }
                    className="w-20 h-10"
                    data-testid="input-default-theme"
                  />
                  <Input
                    value={formData.defaultTheme}
                    onChange={(e) =>
                      setFormData({ ...formData, defaultTheme: e.target.value })
                    }
                    placeholder="#4f46e5"
                    className="flex-1"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="defaultFooterText">Default Footer Text</Label>
                <Input
                  id="defaultFooterText"
                  value={formData.defaultFooterText}
                  onChange={(e) =>
                    setFormData({
                      ...formData,
                      defaultFooterText: e.target.value,
                    })
                  }
                  placeholder="Powered by AI Chatbot Agency"
                  data-testid="input-default-footer"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="defaultWatermark">Default Watermark</Label>
                <Input
                  id="defaultWatermark"
                  value={formData.defaultWatermark}
                  onChange={(e) =>
                    setFormData({
                      ...formData,
                      defaultWatermark: e.target.value,
                    })
                  }
                  placeholder="AI Chatbot"
                  data-testid="input-default-watermark"
                />
              </div>

              <Button
                onClick={handleSave}
                className="w-full"
                data-testid="button-save-theme"
              >
                Save Theme Settings
              </Button>
            </div>
          </Card>

          <Card className="p-6">
            <h2 className="text-lg font-semibold text-foreground mb-4">
              Webhook Testing
            </h2>
            <p className="text-sm text-muted-foreground mb-4">
              Test your webhook configuration to ensure it's working correctly.
            </p>
            <Button
              onClick={handleTestWebhook}
              variant="outline"
              className="w-full"
              data-testid="button-test-webhook"
            >
              Test Webhook
            </Button>
          </Card>
        </div>

        <div>
          <Card className="p-6 sticky top-6">
            <h2 className="text-lg font-semibold text-foreground mb-4">
              Preview
            </h2>
            <div className="border border-border rounded-lg overflow-hidden">
              <div
                className="p-4 text-white font-semibold"
                style={{ backgroundColor: formData.defaultTheme }}
              >
                Chat Preview
              </div>
              <div className="p-4 bg-background space-y-3">
                <div className="bg-muted rounded-lg p-3 max-w-[80%]">
                  <p className="text-sm text-foreground">
                    Welcome! How can I help you today?
                  </p>
                </div>
                <div className="bg-primary text-primary-foreground rounded-lg p-3 max-w-[80%] ml-auto">
                  <p className="text-sm">I need help with pricing</p>
                </div>
              </div>
              <div className="p-3 bg-muted border-t border-border text-center">
                <p className="text-xs text-muted-foreground">
                  {formData.defaultFooterText}
                </p>
              </div>
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}

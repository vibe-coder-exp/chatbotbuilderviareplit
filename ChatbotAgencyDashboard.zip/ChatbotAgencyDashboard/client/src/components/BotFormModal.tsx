import { useState } from "react";
import { type Bot } from "@shared/schema";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

interface BotFormModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (bot: Omit<Bot, "id" | "createdAt">) => void;
  bot?: Bot | null;
}

export default function BotFormModal({ isOpen, onClose, onSave, bot }: BotFormModalProps) {
  const [formData, setFormData] = useState({
    name: bot?.name || "",
    client: bot?.client || "",
    welcomeMessage: bot?.welcomeMessage || "",
    suggestedMessages: bot?.suggestedMessages || ["", "", ""],
    webhookUrl: bot?.webhookUrl || "",
    formWebhookUrl: bot?.formWebhookUrl || "",
    theme: bot?.theme || "#4f46e5",
    headerText: bot?.headerText || "",
    footerText: bot?.footerText || "",
    footerLink: bot?.footerLink || "",
    watermark: bot?.watermark || "",
    chatBubbleShape: bot?.chatBubbleShape || "rounded",
    width: bot?.width || 400,
    height: bot?.height || 500,
    status: bot?.status || "active",
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const suggestedMessages = formData.suggestedMessages.filter((msg) => msg.trim() !== "");
    onSave({
      ...formData,
      suggestedMessages,
    });
    onClose();
  };

  const updateSuggestedMessage = (index: number, value: string) => {
    const newMessages = [...formData.suggestedMessages];
    newMessages[index] = value;
    setFormData({ ...formData, suggestedMessages: newMessages });
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{bot ? "Edit Bot" : "Create New Bot"}</DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-6 mt-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="name">Bot Name</Label>
              <Input
                id="name"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                placeholder="Customer Support Bot"
                required
                data-testid="input-bot-name"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="client">Client</Label>
              <Input
                id="client"
                value={formData.client}
                onChange={(e) => setFormData({ ...formData, client: e.target.value })}
                placeholder="TechCorp Inc."
                required
                data-testid="input-client"
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="welcomeMessage">Welcome Message</Label>
            <Textarea
              id="welcomeMessage"
              value={formData.welcomeMessage}
              onChange={(e) => setFormData({ ...formData, welcomeMessage: e.target.value })}
              placeholder="Hi! How can I help you today?"
              required
              data-testid="input-welcome-message"
            />
          </div>

          <div className="space-y-2">
            <Label>Suggested Messages</Label>
            {formData.suggestedMessages.map((msg, index) => (
              <Input
                key={index}
                value={msg}
                onChange={(e) => updateSuggestedMessage(index, e.target.value)}
                placeholder={`Suggestion ${index + 1}`}
                data-testid={`input-suggestion-${index + 1}`}
              />
            ))}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="theme">Header Color</Label>
              <div className="flex gap-2">
                <Input
                  id="theme"
                  type="color"
                  value={formData.theme}
                  onChange={(e) => setFormData({ ...formData, theme: e.target.value })}
                  className="w-20 h-10"
                  data-testid="input-theme-color"
                />
                <Input
                  value={formData.theme}
                  onChange={(e) => setFormData({ ...formData, theme: e.target.value })}
                  placeholder="#4f46e5"
                  className="flex-1"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="chatBubbleShape">Chat Style</Label>
              <Select
                value={formData.chatBubbleShape}
                onValueChange={(value) => setFormData({ ...formData, chatBubbleShape: value })}
              >
                <SelectTrigger id="chatBubbleShape" data-testid="select-chat-style">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="rounded">Rounded</SelectItem>
                  <SelectItem value="box">Box</SelectItem>
                  <SelectItem value="minimal">Minimal</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="headerText">Header Text</Label>
              <Input
                id="headerText"
                value={formData.headerText}
                onChange={(e) => setFormData({ ...formData, headerText: e.target.value })}
                placeholder="Support Chat"
                data-testid="input-header-text"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="watermark">Watermark</Label>
              <Input
                id="watermark"
                value={formData.watermark}
                onChange={(e) => setFormData({ ...formData, watermark: e.target.value })}
                placeholder="AI Chatbot"
                data-testid="input-watermark"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="footerText">Footer Text</Label>
              <Input
                id="footerText"
                value={formData.footerText}
                onChange={(e) => setFormData({ ...formData, footerText: e.target.value })}
                placeholder="Powered by AI"
                data-testid="input-footer-text"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="footerLink">Footer Link</Label>
              <Input
                id="footerLink"
                value={formData.footerLink}
                onChange={(e) => setFormData({ ...formData, footerLink: e.target.value })}
                placeholder="https://example.com"
                data-testid="input-footer-link"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="webhookUrl">Chat Webhook URL</Label>
              <Input
                id="webhookUrl"
                value={formData.webhookUrl}
                onChange={(e) => setFormData({ ...formData, webhookUrl: e.target.value })}
                placeholder="https://api.example.com/webhook"
                required
                data-testid="input-webhook-url"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="formWebhookUrl">Form Webhook URL</Label>
              <Input
                id="formWebhookUrl"
                value={formData.formWebhookUrl}
                onChange={(e) => setFormData({ ...formData, formWebhookUrl: e.target.value })}
                placeholder="https://api.example.com/form"
                data-testid="input-form-webhook-url"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="width">Width (px)</Label>
              <Input
                id="width"
                type="number"
                value={formData.width}
                onChange={(e) => setFormData({ ...formData, width: parseInt(e.target.value) })}
                placeholder="400"
                required
                data-testid="input-width"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="height">Height (px)</Label>
              <Input
                id="height"
                type="number"
                value={formData.height}
                onChange={(e) => setFormData({ ...formData, height: parseInt(e.target.value) })}
                placeholder="500"
                required
                data-testid="input-height"
              />
            </div>
          </div>

          <div className="flex justify-end gap-3 pt-4 border-t">
            <Button
              type="button"
              variant="outline"
              onClick={onClose}
              data-testid="button-cancel"
            >
              Cancel
            </Button>
            <Button type="submit" data-testid="button-save">
              {bot ? "Update Bot" : "Create Bot"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}

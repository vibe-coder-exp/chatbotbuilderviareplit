import StatCard from "../StatCard";
import { Bot, Activity, MessageSquare } from "lucide-react";

export default function StatCardExample() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 p-6">
      <StatCard
        title="Total Bots"
        value={12}
        icon={Bot}
        iconColor="text-primary"
        iconBgColor="bg-primary/10"
      />
      <StatCard
        title="Active Bots"
        value={9}
        icon={Activity}
        iconColor="text-green-600"
        iconBgColor="bg-green-100"
      />
      <StatCard
        title="Total Messages"
        value="1.2k"
        icon={MessageSquare}
        iconColor="text-purple-600"
        iconBgColor="bg-purple-100"
      />
    </div>
  );
}

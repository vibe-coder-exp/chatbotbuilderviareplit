import BotTable from "../BotTable";
import { type Bot } from "@shared/schema";

export default function BotTableExample() {
  const mockBots: Bot[] = [
    {
      id: "1",
      name: "Customer Support Bot",
      client: "TechCorp Inc.",
      welcomeMessage: "Hi! How can I help you today?",
      suggestedMessages: ["Pricing", "Support", "Contact Sales"],
      webhookUrl: "https://api.techcorp.com/webhook",
      formWebhookUrl: null,
      theme: "#4f46e5",
      headerText: "TechCorp Support",
      footerText: "Powered by AI",
      footerLink: "https://techcorp.com",
      watermark: "TechCorp AI",
      chatBubbleShape: "rounded",
      width: 400,
      height: 500,
      status: "active",
      createdAt: new Date("2024-01-15"),
    },
    {
      id: "2",
      name: "Sales Assistant",
      client: "RetailHub",
      welcomeMessage: "Welcome! Looking for something specific?",
      suggestedMessages: ["Product Info", "Pricing", "Schedule Demo"],
      webhookUrl: "https://api.retailhub.com/webhook",
      formWebhookUrl: null,
      theme: "#7c3aed",
      headerText: "RetailHub Sales",
      footerText: "Shop with confidence",
      footerLink: "https://retailhub.com",
      watermark: "RetailHub",
      chatBubbleShape: "box",
      width: 380,
      height: 550,
      status: "inactive",
      createdAt: new Date("2024-02-20"),
    },
  ];

  return (
    <div className="p-6">
      <BotTable
        bots={mockBots}
        onEdit={(bot) => console.log("Edit bot:", bot)}
        onDelete={(id) => console.log("Delete bot:", id)}
      />
    </div>
  );
}

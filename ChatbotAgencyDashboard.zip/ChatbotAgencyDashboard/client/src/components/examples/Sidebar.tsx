import { useState } from "react";
import { Router, Route } from "wouter";
import Sidebar from "../Sidebar";

export default function SidebarExample() {
  const [isOpen, setIsOpen] = useState(true);

  return (
    <Router>
      <div className="flex h-screen">
        <Sidebar isOpen={isOpen} onClose={() => setIsOpen(false)} />
        <div className="flex-1 p-8">
          <button
            onClick={() => setIsOpen(!isOpen)}
            className="px-4 py-2 bg-primary text-white rounded-lg"
          >
            Toggle Sidebar
          </button>
          <Route path="/dashboard">Dashboard Content</Route>
          <Route path="/bots">Bots Content</Route>
          <Route path="/settings">Settings Content</Route>
        </div>
      </div>
    </Router>
  );
}

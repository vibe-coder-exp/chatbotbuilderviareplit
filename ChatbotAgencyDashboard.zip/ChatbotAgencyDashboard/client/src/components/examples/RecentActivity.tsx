import RecentActivity from "../RecentActivity";

export default function RecentActivityExample() {
  const mockActivities = [
    {
      id: "1",
      type: "created" as const,
      botName: "Customer Support Bot",
      message: "New bot created for TechCorp Inc.",
      timestamp: new Date(Date.now() - 1000 * 60 * 5),
    },
    {
      id: "2",
      type: "updated" as const,
      botName: "Sales Assistant",
      message: "Bot configuration updated",
      timestamp: new Date(Date.now() - 1000 * 60 * 30),
    },
    {
      id: "3",
      type: "error" as const,
      botName: "FAQ Bot",
      message: "Webhook connection failed",
      timestamp: new Date(Date.now() - 1000 * 60 * 60),
    },
  ];

  return (
    <div className="p-6 max-w-2xl">
      <RecentActivity activities={mockActivities} />
    </div>
  );
}

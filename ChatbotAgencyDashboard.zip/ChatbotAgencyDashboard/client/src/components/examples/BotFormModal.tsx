import { useState } from "react";
import BotFormModal from "../BotFormModal";
import { Button } from "@/components/ui/button";

export default function BotFormModalExample() {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <div className="p-6">
      <Button onClick={() => setIsOpen(true)}>Open Form Modal</Button>
      <BotFormModal
        isOpen={isOpen}
        onClose={() => setIsOpen(false)}
        onSave={(bot) => {
          console.log("Bot saved:", bot);
          setIsOpen(false);
        }}
      />
    </div>
  );
}

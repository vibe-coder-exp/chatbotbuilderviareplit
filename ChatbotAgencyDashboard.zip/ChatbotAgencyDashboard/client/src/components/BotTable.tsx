import { type Bot } from "@shared/schema";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Edit, Trash2 } from "lucide-react";
import { format } from "date-fns";

interface BotTableProps {
  bots: Bot[];
  onEdit: (bot: Bot) => void;
  onDelete: (id: string) => void;
}

export default function BotTable({ bots, onEdit, onDelete }: BotTableProps) {
  return (
    <div className="overflow-x-auto">
      <table className="w-full" data-testid="table-bots">
        <thead>
          <tr className="border-b border-border bg-muted/50">
            <th className="px-4 py-3 text-left text-xs font-semibold text-foreground uppercase tracking-wide">
              Bot Name
            </th>
            <th className="px-4 py-3 text-left text-xs font-semibold text-foreground uppercase tracking-wide">
              Client
            </th>
            <th className="px-4 py-3 text-left text-xs font-semibold text-foreground uppercase tracking-wide">
              Status
            </th>
            <th className="px-4 py-3 text-left text-xs font-semibold text-foreground uppercase tracking-wide">
              Created On
            </th>
            <th className="px-4 py-3 text-right text-xs font-semibold text-foreground uppercase tracking-wide">
              Actions
            </th>
          </tr>
        </thead>
        <tbody>
          {bots.map((bot) => (
            <tr
              key={bot.id}
              className="border-b border-border hover-elevate"
              data-testid={`row-bot-${bot.id}`}
            >
              <td className="px-4 py-4">
                <div className="font-medium text-foreground">{bot.name}</div>
              </td>
              <td className="px-4 py-4">
                <div className="text-sm text-foreground">{bot.client}</div>
              </td>
              <td className="px-4 py-4">
                <Badge
                  variant={bot.status === "active" ? "default" : "secondary"}
                  data-testid={`badge-status-${bot.id}`}
                >
                  {bot.status}
                </Badge>
              </td>
              <td className="px-4 py-4">
                <div className="text-sm text-muted-foreground">
                  {format(new Date(bot.createdAt), "MMM dd, yyyy")}
                </div>
              </td>
              <td className="px-4 py-4">
                <div className="flex items-center justify-end gap-2">
                  <Button
                    size="icon"
                    variant="ghost"
                    onClick={() => onEdit(bot)}
                    data-testid={`button-edit-${bot.id}`}
                  >
                    <Edit className="w-4 h-4" />
                  </Button>
                  <Button
                    size="icon"
                    variant="ghost"
                    onClick={() => onDelete(bot.id)}
                    data-testid={`button-delete-${bot.id}`}
                  >
                    <Trash2 className="w-4 h-4 text-destructive" />
                  </Button>
                </div>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

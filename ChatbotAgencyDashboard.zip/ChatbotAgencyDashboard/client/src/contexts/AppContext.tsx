import { createContext, useContext, useState, useEffect, ReactNode } from "react";
import { type Bot } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";

interface AppContextType {
  isAuthenticated: boolean;
  login: (email: string, password: string) => Promise<void>;
  logout: () => void;
  bots: Bot[];
  fetchBots: () => Promise<void>;
  addBot: (bot: Omit<Bot, "id" | "createdAt">) => Promise<void>;
  updateBot: (id: string, bot: Partial<Bot>) => Promise<void>;
  deleteBot: (id: string) => Promise<void>;
  adminSettings: AdminSettings;
  updateAdminSettings: (settings: Partial<AdminSettings>) => void;
}

interface AdminSettings {
  name: string;
  email: string;
  defaultTheme: string;
  defaultFooterText: string;
  defaultWatermark: string;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export function AppProvider({ children }: { children: ReactNode }) {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [bots, setBots] = useState<Bot[]>([]);
  const [adminSettings, setAdminSettings] = useState<AdminSettings>({
    name: "Admin User",
    email: "admin@chatbotagency.com",
    defaultTheme: "#4f46e5",
    defaultFooterText: "Powered by AI Chatbot Agency",
    defaultWatermark: "AI Chatbot",
  });

  const fetchBots = async () => {
    try {
      const response = await fetch("/api/bots");
      if (response.ok) {
        const data = await response.json();
        setBots(data);
      }
    } catch (error) {
      console.error("Failed to fetch bots:", error);
    }
  };

  useEffect(() => {
    if (isAuthenticated) {
      fetchBots();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isAuthenticated]);

  const login = async (email: string, password: string) => {
    try {
      const response = await apiRequest("POST", "/api/auth/login", { 
        username: email, 
        password 
      });

      setIsAuthenticated(true);
    } catch (error) {
      console.error("Login error:", error);
      throw error;
    }
  };

  const logout = () => {
    setIsAuthenticated(false);
    setBots([]);
  };

  const addBot = async (bot: Omit<Bot, "id" | "createdAt">) => {
    try {
      const response = await apiRequest("POST", "/api/bots", bot);
      const newBot = await response.json();
      setBots((prev) => [newBot, ...prev]);
    } catch (error) {
      console.error("Failed to create bot:", error);
      throw error;
    }
  };

  const updateBot = async (id: string, updates: Partial<Bot>) => {
    try {
      const response = await apiRequest("PATCH", `/api/bots/${id}`, updates);
      const updatedBot = await response.json();
      setBots((prev) =>
        prev.map((bot) => (bot.id === id ? updatedBot : bot))
      );
    } catch (error) {
      console.error("Failed to update bot:", error);
      throw error;
    }
  };

  const deleteBot = async (id: string) => {
    try {
      await apiRequest("DELETE", `/api/bots/${id}`);
      setBots((prev) => prev.filter((bot) => bot.id !== id));
    } catch (error) {
      console.error("Failed to delete bot:", error);
      throw error;
    }
  };

  const updateAdminSettings = (settings: Partial<AdminSettings>) => {
    setAdminSettings((prev) => ({ ...prev, ...settings }));
  };

  return (
    <AppContext.Provider
      value={{
        isAuthenticated,
        login,
        logout,
        bots,
        fetchBots,
        addBot,
        updateBot,
        deleteBot,
        adminSettings,
        updateAdminSettings,
      }}
    >
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error("useApp must be used within AppProvider");
  }
  return context;
}
